<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Details</div>
                <div class="panel-body">

                <?php if($user->name != null): ?>
                <p>Your Email : <?php echo e($user->email); ?></p>
                <p>Your Name : <?php echo e($user->name); ?></p>
                <p>Your Company : <?php echo e($user->company_name); ?></p>
                <p>Your Mobile : <?php echo e($user->mobile); ?></p>
                <?php else: ?> 
                    <p>You filled only email</p></br>
                    <p>Your Email : <?php echo e($user->email); ?></p>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>