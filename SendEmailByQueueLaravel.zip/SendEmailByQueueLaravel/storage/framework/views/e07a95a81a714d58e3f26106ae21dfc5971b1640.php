<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">User List</div>
                <div class="panel-body">
                   <table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
           <th>Email</th>
            <th>Company Name</th>
           <th>Mobile</th>

        </tr>
    </thead>
    <tbody>
        <?php if(!empty($data) && $data->count()): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->company_name); ?></td>
                    <td><?php echo e($value->mobile); ?></td>                
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
            <td>
</td>
                <td>There are no data.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo $data->render(); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

  


<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>