<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(url('admin')); ?>">Admin Login</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('public/js/app.js')); ?>"></script>
     <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery/jquery-1.4.4.min.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>



    <script type="text/javascript">
   $( document ).ready(function() 
   {
    $('#secondDiv').hide();
 

});


   // Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("#firstForm").validate({
    // Specify validation rules
    rules: {
      email: {
        required: true,
        email: true
      }
    },
    // Specify validation error messages
    messages: {
      email: {
        required: "Please enter email",
        email: "Please enter a valid email address"
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      var url = 'http://localhost/suffescom/';  
      var data = $('#firstForm').serialize();
      $.ajax({
        url: url+"addUser",
        type: "post",
        data: data ,
        success: function (response) {

            if(response.status == true)
            {
                $('#userId').val(response.id);
                $('#secondDiv').show();
                $('#firstDiv').hide();
 
            }
            else
            {
                $.each(response.error, function( index, value ) {
                  alert( index + ": " + value );
                  $('#error_'+index).html(value);
                });

            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
           console.log(textStatus, errorThrown);
        }


    });
    }
  });

    $("#secondForm").validate({
    // Specify validation rules
    rules: {
      name: {
        required: true,
      },
      company_name:{
        required:true,
      },
      mobile:{
        required:true,
      }
    },
    // Specify validation error messages
    messages: {
      name: {
        required: "Please enter name",
      },
       company_name: {
        required: "Please enter copany name",
      },
       mobile: {
        required: "Please enter mobile",
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      var url = 'http://localhost/suffescom/';  
      var data = $('#secondForm').serialize();
      $.ajax({
        url: url+"updateUser",
        type: "post",
        data: data ,
        success: function (response) {

            if(response.status == true)
            {

                alert('You have completed both form')
                    location.reload();
 
            }
            else
            {
                $.each(response.error, function( index, value ) {
                  $('#error_'+index).html(value);
                });

            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
           console.log(textStatus, errorThrown);
        }


    });
    }
  });
});


</script>

</body>
</html>
