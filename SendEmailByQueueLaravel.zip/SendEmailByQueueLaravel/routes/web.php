<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('register');
});

Route::get('/admin','AdminController@index');
Route::get('/admin/login','AdminController@index')->name('admin');
Route::group(['middleware' => 'admin'], function () {
	    Route::get('admin', 'adminController@adminDashboard');
 });
Route::post('/adminlogin','AdminController@adminlogin')->name('adminlogin');
Auth::routes();
Route::post('/addUser','UserController@addUser');
Route::post('/updateUser','UserController@updateUser');
Route::get('/job','UserController@job');
Route::get('/home', 'HomeController@index')->name('home');
