@extends('layouts.front')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">User List</div>
                <div class="panel-body">
                   <table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
           <th>Email</th>
            <th>Company Name</th>
           <th>Mobile</th>

        </tr>
    </thead>
    <tbody>
        @if(!empty($data) && $data->count())
            @foreach($data as $key => $value)
                <tr>
                    <td>{{ $value->name }}</td>
                    <td>{{ $value->email }}</td>
                    <td>{{ $value->company_name }}</td>
                    <td>{{ $value->mobile }}</td>                
                </tr>
            @endforeach
        @else
            <tr>
            <td>
</td>
                <td>There are no data.</td>
            </tr>
        @endif
    </tbody>
</table>

<?php echo $data->render(); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

  

