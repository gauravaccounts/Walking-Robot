<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Details</div>
                <div class="panel-body">

                @if($user->name != null)
                <p>Your Email : {{$user->email}}</p>
                <p>Your Name : {{$user->name}}</p>
                <p>Your Company : {{$user->company_name}}</p>
                <p>Your Mobile : {{$user->mobile}}</p>
                @else 
                    <p>You filled only email</p></br>
                    <p>Your Email : {{$user->email}}</p>
                @endif
                </div>
            </div>
        </div>
    </div>
</div>