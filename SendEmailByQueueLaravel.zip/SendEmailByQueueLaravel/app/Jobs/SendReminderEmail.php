<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Contracts\Mail\Mailer;
use App\Jobs\Job;
use App\User;
class SendReminderEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $userId;

    public function __construct($id)
    {
         $this->userId =$id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    /*Send Email to user*/
    public function handle(Mailer $mailer)
    {

            $this->userId;
            $user = User::findOrFail( $this->userId);
            $mailer->send('userdetails', ['user' => $user], function ($m) use ($user) {
            $m->from('gaurav.luckycoin@gmail.com', 'Suffescom');
            if($user->name!=null)
            {
                $name = $user->name;
            }
            else
            {
                $name = $user->email;
            }
            $m->to($user->email, $name)->subject('Your Inforamtion');
            });
    }
}
