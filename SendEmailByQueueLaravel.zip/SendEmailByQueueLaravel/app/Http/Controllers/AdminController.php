<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Crypt;
use Validator, Input, Redirect;
use Illuminate\Support\Facades\Hash;
use Session;
use App;
use Illuminate\Support\Facades\DB;
use Response;
use Event;
use App\Events\SendEmail;
use App\Jobs\SendReminderEmail;
use App\User;
use Auth;
class AdminController extends Controller
{
	public function index()
	{
		    return view('adminlogin');

	}
    public function adminLogin(Request $Request)
    {
    	$email 		= $Request->get('email');
		$password 	= $Request->get('password');
		if(Auth::attempt(['email' => $email,'password' => $password]))
		{
				   return redirect('admin');
		}
		else
		{
		    Session::flash ( 'message', "Invalid Credentials , Please try again." );
            return Redirect::back ();
		}
    }
    public function adminDashboard(Request $Request)
    {
    		$data = User::where('userType','!=','Admin')->paginate(5);
    		return view('user',compact('data'));
    }
}
