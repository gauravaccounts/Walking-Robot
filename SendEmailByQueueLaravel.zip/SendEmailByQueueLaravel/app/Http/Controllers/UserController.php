<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Crypt;
use Validator, Input, Redirect;
use Illuminate\Support\Facades\Hash;
use Session;
use App;
use Illuminate\Support\Facades\DB;
use Response;
use Event;
use App\Events\SendEmail;
use App\Jobs\SendReminderEmail;
use App\User;
class UserController extends Controller
{
	public function addUser(Request $Request)
	{
        $rules = array('email' => 'required|email|unique:users');
        $Validator = Validator::make($Request->all(),$rules);
        if($Validator->fails())
        {
        		$errorsArray = array();
	        	  foreach($Validator->messages()->getMessages() as $field_name => $messages) {
				            // Go through each message for this field.
				            foreach($messages AS $message) 
				            {
				            	$errorsArray[$field_name] = $message;
				            }
	        		}
        		return Response::json(array('status'=>false,'error'=>$errorsArray));
        }
        else
        {
        	$email = 	$Request->get('email');
        	$insertArray = array('email'=>$email,'created_at'=>date('Y-m-d'));
        	$id = DB::table('users')->insertGetId($insertArray);
        	if($id)
        	{
        			event(new SendEmail($id));
        			$job = (new SendReminderEmail($id))->delay(20*60);
        			$this->dispatch($job);
        		return Response::json(array('id'=>$id,'status'=>true));
        	}
        }
	}
	public function updateUser(Request $Request)
	{
		$name 			= $Request->input('name');
		$userId 		= $Request->input('userId');
		$company_name 	= $Request->input('company_name');
		$mobile 		= $Request->input('mobile');
        $rules 			= array('name' => 'required','company_name'=>'required','mobile'=>'required|digits:10');
        $Validator 		= Validator::make($Request->all(),$rules);
        if($Validator->fails())
        {
        		$errorsArray = array();
	        	  foreach($Validator->messages()->getMessages() as $field_name => $messages) {
				            // Go through each message for this field.
				            foreach($messages AS $message) 
				            {
				            	$errorsArray[$field_name] = $message;
				            }
	        		}
        		return Response::json(array('status'=>false,'error'=>$errorsArray));
        }
        else
        {
        	$UpdatedArray = array('name'=>$name,'company_name'=>$company_name,'mobile'=>$mobile);
		        	$id = DB::table('users')
		        		->where('id',$userId)
		        		->update($UpdatedArray);
        	if($id)
        	{
        		return Response::json(array('id'=>$userId,'status'=>true));
        	}
        }
	}
}
