<?php

namespace App\Listeners;

use App\Events\SendEmail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Mail;
use App\User;
class EmailListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SendEmail  $event
     * @return void
     */
    /*Send Email to admin */
    public function handle(SendEmail $event)
    {
        $id = $event->userId;
        $user = User::findOrFail($id);
        $admindetails = User::where('userType','Admin')->first();
        Mail::send('email', ['user' => $user], function ($m) use ($user,$admindetails) {
            $m->from('gaurav.luckycoin@gmail.com', 'Suffescom');
            $m->to($admindetails->email,$admindetails->name)->subject('New user register');
        });

    }
}
